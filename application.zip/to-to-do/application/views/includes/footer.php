<script src="http://code.jquery.com/jquery-2.2.4.min.js" type="text/javascript" charset="utf-8"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js" type="text/javascript" charset="utf-8"></script>
<script defer src="https://code.getmdl.io/1.2.1/material.min.js" type="text/javascript" charset="utf-8"></script>

	<script type="text/javascript" charset="utf-8">
		$('input').click(function(){
			$(this).select();	
		});
        
	</script>

</body>
</html>